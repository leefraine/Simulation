//start
using System.Text;
using System.Linq;
using System;
﻿using Microsoft.Win32.SafeHandles;
using System.ComponentModel;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Permissions;
using System.Security.Principal;


namespace Tools
{
    public class Impersonator
    {

        [PermissionSet(SecurityAction.Demand, Name = "FullTrust")]
        public class Impersonation : IDisposable
        {
            private readonly SafeTokenHandle _handle;
            private readonly WindowsImpersonationContext _context;

            private const int LOGON32_LOGON_NEW_CREDENTIALS = 9;

            public Impersonation(string domain, string username, string password)
            {
                var ok = LogonUser(username, domain, password,
                               LOGON32_LOGON_NEW_CREDENTIALS, 0, out this._handle);
                if (!ok)
                {
                    var errorCode = Marshal.GetLastWin32Error();
                    throw new ApplicationException(string.Format("Could not impersonate the elevated user.  LogonUser returned error code {0}.", errorCode));
                }

                this._context = WindowsIdentity.Impersonate(this._handle.DangerousGetHandle());
            }

            public void Dispose()
            {
                this._context.Dispose();
                this._handle.Dispose();
            }

            [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
            private static extern bool LogonUser(String lpszUsername, String lpszDomain, String lpszPassword, int dwLogonType, int dwLogonProvider, out SafeTokenHandle phToken);

            public sealed class SafeTokenHandle : SafeHandleZeroOrMinusOneIsInvalid
            {
                private SafeTokenHandle()
                    : base(true) { }

                [DllImport("kernel32.dll")]
                [ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
                [SuppressUnmanagedCodeSecurity]
                [return: MarshalAs(UnmanagedType.Bool)]
                private static extern bool CloseHandle(IntPtr handle);

                protected override bool ReleaseHandle()
                {
                    return CloseHandle(handle);
                }
            }
        }
    }

    public class AToken
    {
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool CloseHandle(IntPtr hObject);

        [DllImport("Advapi32.dll", SetLastError = true)]
        private static extern bool RevertToSelf();

        [DllImport("advapi32.dll", SetLastError = true)]
        public static extern bool ImpersonateLoggedOnUser(IntPtr hToken);

        [DllImport("advapi32.dll", SetLastError = true)]
        public static extern bool LogonUserA(
            string lpszUsername,
            string lpszDomain,
            string lpszPassword,
            LOGON_TYPE dwLogonType,
            LOGON_PROVIDER dwLogonProvider,
            ref IntPtr phToken);

        [Flags]
        public enum LOGON_TYPE : uint
        {
            LOGON32_LOGON_INTERACTIVE = 2, //will not work for sacrify, still active
            LOGON32_LOGON_NETWORK, //will not work for sacrify, still active
            LOGON32_LOGON_BATCH, //will not work for sacrify, still active
            LOGON32_LOGON_SERVICE, //will not work for sacrify, still active
            LOGON32_LOGON_UNLOCK = 7, //will not work for sacrify, still active
            LOGON32_LOGON_NETWORK_CLEARTEXT, //will not work for sacrify, still active
            LOGON32_LOGON_NEW_CREDENTIALS
        }

        [Flags]
        public enum LOGON_PROVIDER : uint
        {
            LOGON32_PROVIDER_DEFAULT,
            LOGON32_PROVIDER_WINNT35,
            LOGON32_PROVIDER_WINNT40,
            LOGON32_PROVIDER_WINNT50
        }

        public static bool MakeToken(string Username, string Domain, string Password, LOGON_TYPE LogonType = LOGON_TYPE.LOGON32_LOGON_NEW_CREDENTIALS)
        {
            IntPtr hProcessToken = IntPtr.Zero;
            if (!LogonUserA(
                Username, Domain, Password,
                LogonType,
                LOGON_PROVIDER.LOGON32_PROVIDER_WINNT50,
                ref hProcessToken))
            {
                Console.Error.WriteLine(Encoding.UTF8.GetString(Convert.FromBase64String("TG9nb25Vc2VyQSgpIEVycm9yOiA=")) + new Win32Exception(Marshal.GetLastWin32Error()).Message);
                return false;
            }

            if (!ImpersonateLoggedOnUser(hProcessToken))
            {
                Console.Error.WriteLine(Encoding.UTF8.GetString(Convert.FromBase64String("SW1wZXJzb25hdGVMb2dnZWRPblVzZXIoKSBFcnJvcjog")) + new Win32Exception(Marshal.GetLastWin32Error()).Message);
                CloseHandle(hProcessToken);
                return false;
            }
            return true;
        }

        public static bool RevertFromToken()
        {
            if (!RevertToSelf())
            {
                Console.Error.WriteLine(Encoding.UTF8.GetString(Convert.FromBase64String("UmV2ZXJ0VG9TZWxmKCkgRXJyb3I6IA==")) + new Win32Exception(Marshal.GetLastWin32Error()).Message);
                return false;
            }
            return true;
        }
    }
}